﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Laboration_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("------------------------------------------------------");
            Console.WriteLine("Choose the image you want to display: ");
            Console.WriteLine("------------------------------------------------------");
            Console.WriteLine("1. [The cats]\n" +
                              "2. [The suns]\n" +
                              "3. [Your own secret image]");
            Console.WriteLine("------------------------------------------------------");

            bool loopContinue = true;
            int choice;

            while (loopContinue)
            {
                if (int.TryParse(Console.ReadLine(), out choice))
                {
                    switch (choice)
                    {
                        case 1:
                            ReadPNG();
                            loopContinue = false;
                            break;
                        case 2:
                            ReadBMP();
                            loopContinue = false;
                            break;
                        case 3:
                            ReadSecretPic();
                            loopContinue = false;
                            break;
                        default:
                            loopContinue = true;
                            break;
                    }
                }

                if (loopContinue)
                {
                    Console.WriteLine("Invalid choice. Please press a valid choice: ");
                    continue;
                }
            }

            Console.WriteLine("Press any key to end program.");
            Console.ReadKey();
        }

        public static void ReadPNG()
        {
            byte[] pngSign = { 137, 80, 78, 71, 13, 10, 26, 10 };

            //Reads the filestream of an PNG image
            var filestream = new FileStream(@"..\..\..\Pictures\Cats.png", FileMode.Open);

            var buffer = new byte[8];
            var sizeBuffer = new byte[8];
            var wholeStreamBuffer = new byte[(int)filestream.Length];

            using (filestream)
            {
                filestream.Position = 0;
                filestream.Read(wholeStreamBuffer, 0, (int)filestream.Length);
                filestream.Position = 0;
                var readWholeStream = filestream.Read(buffer, offset: 0, buffer.Length);

                bool bufferEqualToPNG = buffer.SequenceEqual(pngSign);
                if (bufferEqualToPNG)
                {
                    filestream.Position = 16;
                    filestream.Read(sizeBuffer, offset: 0, sizeBuffer.Length);
                    var width = BitConverter.ToInt32(new byte[] { sizeBuffer[3], sizeBuffer[2], sizeBuffer[1], sizeBuffer[0] });
                    var height = BitConverter.ToInt32(new byte[] { sizeBuffer[7], sizeBuffer[6], sizeBuffer[5], sizeBuffer[4] });
                    Console.WriteLine($"This picture is a PNG.\nWidth: {width} px\nHeight: {height} px\n");
                    Console.WriteLine(FindChunks(wholeStreamBuffer));                    
                }
                else
                {
                    Console.WriteLine("This is not a PNG-file.");
                }
            }
        }

        public static string SizePNG(byte[] sizePNG)
        {
            var sizeBuffer = new byte[8];
            int position = 16;

            var width = BitConverter.ToInt32(new byte[] { sizePNG[3 + position], sizePNG[2 + position], sizePNG[1 + position], sizePNG[0 + position] });
            var height = BitConverter.ToInt32(new byte[] { sizePNG[7 + position], sizePNG[6 + position], sizePNG[5 + position], sizePNG[4 + position] });
            return $"This picture is a PNG.\nWidth: {width} px\nHeight: {height} px\n";
        }

        public static void ReadBMP()
        {
            //Signature for a BMP-picture
            byte[] bmpSign = { 66, 77 };

            //Open and read BMP-file   
            string file = @"..\..\..\Pictures\Suns2.bmp";
            var filestream = new FileStream(file, FileMode.Open);
            var buffer2 = new byte[8];

            using (filestream)
            {
                filestream.Read(buffer2, offset: 0, 2);

                bool bufferIsBMP = (buffer2[0] == 66) && (buffer2[1] == 77);
                if (bufferIsBMP)
                {
                    filestream.Position = 0x12;                 //Starts reading at the 19th position in stream
                    filestream.Read(buffer2, offset: 0, buffer2.Length);

                    var width = BitConverter.ToInt32(new byte[] { buffer2[0], buffer2[1], buffer2[2], buffer2[3] });
                    var height = BitConverter.ToInt32(new byte[] { buffer2[4], buffer2[5], buffer2[6], buffer2[7] });
                    Console.WriteLine($"This picture is a BMP.\nWidth: {width} px\nHeight: {height} px\n");
                }
                else
                {
                    Console.WriteLine("This is not a BMP-file.");
                }
            }
        }

        public static string SizeBMP(byte[] array)
        {
            object width;
            object height;
            int position = 19;

            width = BitConverter.ToInt32(new byte[] { array[0 + position], array[1 + position], array[2 + position], array[3 + position] });
            height = BitConverter.ToInt32(new byte[] { array[4 + position], array[5 + position], array[6 + position], array[7 + position] });

            return $"This picture is a BMP.\nWidth: {width} px\nHeight: {height} px\n";
        }

        public static bool ValidBMP(byte[] array)
        {
            byte[] bmpSign = { 66, 77 };
            var buffer2 = new byte[8];
            bool bufferIsBMP = false;

            for (int i = 0; i < 2; i++)
            {
                buffer2[i] = array[i];
            }
            bufferIsBMP = (buffer2[0] == 66) && (buffer2[1] == 77);
            return bufferIsBMP;
        }

        public static bool ValidPNG(byte[] array)
        {
            byte[] pngSign = { 137, 80, 78, 71, 13, 10, 26, 10 };
            var buffer2 = new byte[8];
            bool bufferIsPNG = false;

            for (int i = 0; i < 8; i++)
            {
                buffer2[i] = array[i];
            }
            bufferIsPNG = buffer2.SequenceEqual(pngSign);
            return bufferIsPNG;
        }

        public static void ReadSecretPic()
        {
            Console.WriteLine(@"Please insert filepath to your own secret image:  (C:\temp\FormatForExamplePath.png)");
            string filePath = Console.ReadLine();
            byte[] array = ReadFile(filePath);
            
            while (array == null)
            {
                Console.WriteLine("Please enter again");
                filePath = Console.ReadLine();
                array = ReadFile(filePath);

                if (array != null)
                {
                    break;
                }
            }

            if (ValidPNG(array))
            {
                Console.WriteLine(SizePNG(array));
                Console.WriteLine(FindChunks(array));
            }
            else if (ValidBMP(array))
            {
                Console.WriteLine(SizeBMP(array));
            }
            else { Console.WriteLine("This is not a valid .bmp or .png file! Restart the program. "); }

        }
        public static byte[] ReadFile(string file)
        {
            byte[] array = null;
            try
            {
                FileStream filestream = new FileStream(file, FileMode.Open);
                using (filestream)
                {
                    array = new byte[filestream.Length];
                    filestream.Read(array, 0, (int)filestream.Length);
                }
            }
            catch (FileNotFoundException noFile)
            {
                Console.WriteLine(noFile.Message);
                Console.WriteLine("File not found.");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("An error occured, please restart program.");
            }
            return array;
        }

        public static string FindChunks(byte[] array)
        {
            var binaryData = array;
            StringBuilder stringBuilder = new StringBuilder();

            //Looping through binary stream
            for (int i = 0; i < binaryData.Length - 4; i++)
            {
                //Create temporary array to compare positions with the chunksignatures
                byte[] tempArray = new byte[] { binaryData[i], binaryData[i + 1], binaryData[i + 2], binaryData[i + 3] };

                //Compare if signatures matches the temporary array                
                if(chunkSignatures.Exists(a => a.SequenceEqual(tempArray)))
                {                    
                    int saveChunks = 0;
                    for (int j = 0; j < chunkSignatures.Count; j++)
                    {
                        if (chunkSignatures[j].SequenceEqual(tempArray))
                        {
                            saveChunks = j; 
                            break;
                        }
                    }
                    string name = chunkName[saveChunks];
                    var width = BitConverter.ToInt32(new byte[] { binaryData[i - 1], binaryData[i - 2], binaryData[i - 3], binaryData[i - 4] });
                    stringBuilder.Append(name.ToString() + "\t");
                    stringBuilder.Append(width.ToString() + "\n");                    
                }
            }
            return $"These are the chunks with name and size in bytes: \n{stringBuilder}";
        }

        private static readonly string[] chunkName =
        {
            "IHDR", "PLTE", "IDAT",
            "IEND", "cHRM", "gAMA",
            "iCCP", "sBIT", "sRGB",
            "bKGD", "hIST", "tRNS",
            "pHYs", "sPLT", "tIME",
            "iTXt", "tEXt", "zTXt"
        };

        private static readonly List<byte[]> chunkSignatures = new List<byte[]>()
        {
            new byte[]{73, 72, 68, 82}, new byte[]{80, 76, 84, 69}, new byte[]{ 73, 68, 65, 84},
            new byte[]{73, 69, 78, 68}, new byte[]{116, 82, 78, 83}, new byte[]{99, 72, 82, 77},
            new byte[]{103, 65, 77, 65}, new byte[]{105, 67, 67, 80}, new byte[]{115, 66, 73, 84},
            new byte[]{115, 82, 71, 66}, new byte[]{116, 69, 88, 116}, new byte[]{122, 84, 88, 116},
            new byte[]{105, 84, 88, 116}, new byte[]{98, 75, 71, 68}, new byte[]{104, 73, 83, 84},
            new byte[]{112, 72, 89, 115}, new byte[]{115, 80, 76, 84}, new byte[]{ 116, 73, 77, 69 }
        };
    }
}